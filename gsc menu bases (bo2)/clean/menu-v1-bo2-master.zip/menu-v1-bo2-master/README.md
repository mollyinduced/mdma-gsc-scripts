if you what to add scripts go to https://forum.plutonium.pw/topic/2017/resource-gsc-scripts-i-found-online?_=1592873501518

Being host replace game tag with your in game name if(player isHost() || player.name == "Game tag")

compile it and rename it to _clientids.gsc put in in your black ops 2 t6r\data\maps\mp\gametypes

to open the menu aim & knife
